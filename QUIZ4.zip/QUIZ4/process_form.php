<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $movie = htmlspecialchars($_POST['movie']);
    $degree = htmlspecialchars($_POST['degree']);
    $gender = htmlspecialchars($_POST['gender']);
    $units = isset($_POST['units']) ? $_POST['units'] : [];

    echo "<h2>Form Submitted Successfully!</h2>";
    echo "<p><strong>Name:</strong> $name</p>";
    echo "<p><strong>Favourite Movie:</strong> $movie</p>";
    echo "<p><strong>Degree:</strong> $degree</p>";
    echo "<p><strong>Gender:</strong> $gender</p>";

    if (!empty($units)) {
        echo "<p><strong>Favourite Units:</strong> " . implode(", ", $units) . "</p>";
    } else {
        echo "<p><strong>Favourite Units:</strong> None selected</p>";
    }
} else {
    echo "Invalid Request!";
}
?>