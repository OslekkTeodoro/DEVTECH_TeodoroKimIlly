<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize user inputs
    $name = htmlspecialchars($_POST['name']);
    $movie = htmlspecialchars($_POST['movie']);
    $degree = htmlspecialchars($_POST['degree']);
    $gender = htmlspecialchars($_POST['gender']);
    $units = isset($_POST['units']) ? $_POST['units'] : [];

    // Display the formatted output
    echo "<div style='width: 400px; margin: auto;'>";
    echo "<div style='background-color: blue; color: white; text-align: center; padding: 10px;'>";
    echo "<h3>postform_submitted.php</h3>";
    echo "</div>";
    echo "<h2>Hello $name</h2>";
    echo "<p>You like movie \"$movie\"</p>";
    echo "<p>You are enrolled in " . ($degree == 'Bachelor' ? "Bachelor's Degree" : $degree . "'s Degree") . ".</p>";
    echo "<p>Your gender is $gender.</p>";
    if (!empty($units)) {
        echo "<p>Your favorite subject is " . htmlspecialchars($units[0]) . ".</p>"; // Displays the first selected subject
    } else {
        echo "<p>You have not selected any favorite subject.</p>";
    }
    echo "</div>";
} else {
    echo "Invalid Request!";
}
?>