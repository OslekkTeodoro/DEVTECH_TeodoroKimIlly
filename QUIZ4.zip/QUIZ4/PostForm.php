<!DOCTYPE html>
<html>
<head>
    <title>PostForm.php</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 300px;
            margin: auto;
        }
        .header {
            background-color: blue;
            color: white;
            text-align: center;
            padding: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h3>PostForm.php</h3>
        </div>
        <form action="process_form.php" method="POST">
            <div class="form-group">
                <label for="name">My name is:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="movie">My favourite movie is:</label>
                <input type="text" id="movie" name="movie" required>
            </div>
            <div class="form-group">
                <label for="degree">My degree is:</label>
                <select id="degree" name="degree">
                    <option value="Bachelor">Bachelor</option>
                    <option value="Master">Master</option>
                    <option value="PhD">PhD</option>
                </select>
            </div>
            <div class="form-group">
                <label>Gender:</label>
                <input type="radio" id="male" name="gender" value="Male" required>
                <label for="male">Male</label>
                <input type="radio" id="female" name="gender" value="Female" required>
                <label for="female">Female</label>
            </div>
            <div class="form-group">
                <label for="units">My favourite unit(s):</label>
                <select id="units" name="units[]" multiple>
                    <option value="Math">Math</option>
                    <option value="Science">Science</option>
                    <option value="History">History</option>
                    <option value="Arts">Arts</option>
                </select>
            </div>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>