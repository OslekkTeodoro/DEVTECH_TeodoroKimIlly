class Person{
    constructor(name, age, country, birthplace){
        this.name = name;
        this.age = age;
        this.country = country;
        this.birthplace = birthplace;
    }
    displayDetails(){
        console.log(`name: ${this.name}`);
        console.log(`age: ${this.age}`);
        console.log(`country: ${this.country}`);
        console.log(`birthplace: ${this.birthplace}`);

      }
    }
    //Create instances of the Person class
    const person1 = new Person('Rico Galang', 25, 'Australia', 'Manila');
    const person2 = new Person('Richard Topaz', 40, 'Netherlands', 'Sucat');
    const person3 = new Person('Pia Lim ', 33, 'Singapore', 'Rizal');

   // Display details of person1
    console.log('\nPerson-1 Details:');
    person1.displayDetails();

   // Display details of person2
    console.log('\nPerson-2 Details:');
    person2.displayDetails();

    //Display details of person3
    console.log('\nPerson-3 Details:');
    person3.displayDetails();


    

