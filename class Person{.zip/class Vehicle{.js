class Vehicle{
    constructor(make, model, year, ownername, door){
        this.make = make;
        this.model = model;
        this.year = year;
        this.ownername = ownername;
        this.door = door;
    }
    displayDetails(){
        console.log(`make: ${this.make}`);
        console.log(`model: ${this.model}`);
        console.log(`year: ${this.year}`);
        console.log(`ownername: ${this.ownername}`);
        console.log(`door: ${this.door}`);

      }
    }
    //Create instances of the Person class
    const car1 = new Vehicle(`Ford`,`F-150`, 2020, `Joshua`);
    const car2 = new Vehicle(`Honda`,`Accord`, 2023, `Rica`, 4);
    

   // Display details of person1
    console.log(`Vehicle Details: `);
    car1.displayDetails();

   // Display details of person2
    console.log(`nVehicle Details:`);
    car2.displayDetails();

