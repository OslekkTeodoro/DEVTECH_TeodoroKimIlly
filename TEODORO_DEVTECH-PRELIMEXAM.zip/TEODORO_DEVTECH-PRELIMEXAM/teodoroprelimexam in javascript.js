const book1 = {
    title: "Alamat ng Waling Waling",
    author: "Zaito",
    PublicationYear: 2016,
    genre: "Horror",
    price: 100.000, 
    
    
    displayDetails: function() {
        console.log(`Title: ${this.title}`);
        console.log(`Author: ${this.author}`);
        console.log(`Publication Year: ${this.PublicationYear}`);
        console.log(`Genre: ${this.genre}`);
        console.log(`Price: $${this.price.toFixed(2)}`); // Display price
    },

    
    updateYear: function(newYear) {
        this.yearPublished = newYear;
        console.log(`The publication Year has been updated to: ${this.PublicationYear}`);
    }
};


const book2 = {
    title: "3 idiots",
    author: "John Mark E Madaldal",
    PublicationYear: 2000,
    genre: "Comedy",
    price: 11.50, 
    
    
    displayDetails: function() {
        console.log(`Title: ${this.title}`);
        console.log(`Author: ${this.author}`);
        console.log(`Publication Year: ${this.PublicationYear}`);
        console.log(`Genre: ${this.genre}`);
        console.log(`Price: $${this.price.toFixed(2)}`); // Display price
    },

    
    updateYear: function(newYear) {
        this.PublicationYear = newYear;
        console.log(`The publication year has been updated to: ${this.Pu}`);
    }
};


const book3 = {
    title: "The Embalsamador",
    author: "Emmerson D Magiba",
    PublicationYear: 1999,
    genre: "Fiction",
    price: 10.00, 
    
  
    displayDetails: function() {
        console.log(`Title: ${this.title}`);
        console.log(`Author: ${this.author}`);
        console.log(`Publication Year: ${this.PublicationYear}`);
        console.log(`Genre: ${this.genre}`);
        console.log(`Price: $${this.price.toFixed(2)}`); // Display price
    },

    
    updateYear: function(newYear) {
        this.yearPublished = newYear;
        console.log(`The publication year has been updated to: ${this.PublicationYear}`);
    }
};


book1.displayDetails();
book2.displayDetails();
book3.displayDetails();


book1.updateYear(2022);
book2.updateYear(2021);
book3.updateYear(2023);


book1.displayDetails();
book2.displayDetails();
book3.displayDetails();
